"""具有明确证据不确定性的研究审计产物模型模式定义模块。"""

from __future__ import annotations

import logging
from enum import StrEnum
from typing import Annotated, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

logger = logging.getLogger(__name__)


class FindingStatus(StrEnum):
    """审计核实状态枚举。"""

    # 已有确凿原文证据支撑核实
    VERIFIED = "verified"
    # 存在疑似不一致或存疑
    SUSPECTED = "suspected"
    # 证据不足（如封闭文献无法获取全文）
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


NonEmptyText = Annotated[str, Field(min_length=1)]
PageNumber = Annotated[int, Field(ge=1)]
Sha256Hex = Annotated[str, Field(pattern=r"^[a-fA-F0-9]{64}$")]


class EvidenceRef(BaseModel):
    """可追溯且不可变的证据源位置定义模型。"""

    # 禁止模型包含未声明的多余字段
    model_config = ConfigDict(extra="forbid")

    # 文档唯一标识符（如 DOI 或内部编号）
    document_id: NonEmptyText
    # 证据所在的页码，必须大于等于 1
    page: PageNumber
    # 原始文档的 SHA-256 哈希值，确保内容防篡改与精准对应
    source_sha256: Sha256Hex
    # 从原始文献中抽取的支持证据原文摘录
    excerpt: NonEmptyText


class AuditFinding(BaseModel):
    """有证据支撑的审计结论模型（严禁主观推测作者意图）。"""

    # 禁止模型包含未声明的多余字段
    model_config = ConfigDict(extra="forbid")

    # 待校验的核心论点或引用主张
    claim: NonEmptyText
    # 审计核实状态：verified（已核实）、suspected（存疑）、insufficient_evidence（证据不足）
    status: FindingStatus
    # 支撑该发现的证据引用列表
    evidence: list[EvidenceRef] = Field(default_factory=list)

    @model_validator(mode="after")
    def require_evidence_for_verification(self) -> Self:
        """防止在缺乏可追溯证据源的情况下生成已核实的审计结论。

        :return: 验证通过后的当前 AuditFinding 实例。
        :rtype: Self
        :raises ValueError: 当结论状态为 'verified'（已核实）却未提供任何证据时抛出。
        :author: tongliga
        :date: 2026-10-19
        """
        # 第一步：记录核验状态与关联证据数量诊断日志
        logger.debug(
            "require_evidence_for_verification_checked",
            extra={
                "event_fields": {
                    "status": self.status.value,
                    "evidence_count": len(self.evidence),
                }
            },
        )
        # 第二步：断言强约束——已核实结论必须至少提供一条非空证据引用
        if self.status == FindingStatus.VERIFIED and not self.evidence:
            raise ValueError("Verified findings require at least one evidence reference")
        return self


class AuditReport(BaseModel):
    """学术审计交付报告的数据模式。"""

    # 禁止模型包含未声明的多余字段
    model_config = ConfigDict(extra="forbid")

    # 接受审计的手稿唯一标识符
    manuscript_id: NonEmptyText
    # 审计发现与问题列表
    findings: list[AuditFinding] = Field(default_factory=list)
    # 审计过程中客观存在的局限性说明（如某些封闭文献无法获取）
    limitations: list[str] = Field(default_factory=list)


__all__ = [
    "AuditFinding",
    "AuditReport",
    "EvidenceRef",
    "FindingStatus",
    "NonEmptyText",
    "PageNumber",
    "Sha256Hex",
]
